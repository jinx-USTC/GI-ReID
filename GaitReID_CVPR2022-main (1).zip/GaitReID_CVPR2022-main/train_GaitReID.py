#!/usr/bin/env python3
# -*- coding: utf-8 -*-
'''
Author             : jin xin (kevin.jx@alibaba-inc.com)
Date               : 2022-05-23 11:14
Last Modified By   : jin xin (kevin.jx@alibaba-inc.com)
Last Modified Date : 2022-06-18 18:43
Description        : CVPR-2022
-------- 
Copyright (c) 2022 Alibaba Inc. 
'''

from __future__ import print_function
from __future__ import division

import os
import sys
import time
import datetime
import os.path as osp
import numpy as np
import cv2

import torch
import torch.nn as nn
import torch.backends.cudnn as cudnn
from torch.optim import lr_scheduler
import torch.optim as optim

from args import argument_parser, image_dataset_kwargs, optimizer_kwargs
from torchreid.data_manager import ImageDataManager
from torchreid import models
from torchreid.losses import CrossEntropyLoss, TripletLoss, DeepSupervision, FullTripletLoss, CFLLoss
from torchreid.utils.iotools import save_checkpoint, check_isfile
from torchreid.utils.avgmeter import AverageMeter
from torchreid.utils.loggers import Logger, RankLogger
from torchreid.utils.torchtools import count_num_param, open_all_layers, open_specified_layers
from torchreid.utils.reidtools import visualize_ranked_results
from torchreid.eval_metrics import evaluate
from torchreid.samplers import RandomIdentitySampler
from torchreid.optimizers import init_optimizer

# global variables
parser = argument_parser()
args = parser.parse_args()


def main():
    global args

    torch.manual_seed(args.seed)
    if not args.use_avai_gpus: os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu_devices
    use_gpu = torch.cuda.is_available()
    if args.use_cpu: use_gpu = False
    log_name = 'log_test.txt' if args.evaluate else 'log_train.txt'
    sys.stdout = Logger(osp.join(args.save_dir, log_name))
    print("==========\nArgs:{}\n==========".format(args))

    if use_gpu:
        print("Currently using GPU {}".format(args.gpu_devices))
        cudnn.benchmark = True
        torch.cuda.manual_seed_all(args.seed)
    else:
        print("Currently using CPU, however, GPU is highly recommended")

    print("Initializing image data manager")
    dm = ImageDataManager(use_gpu, **image_dataset_kwargs(args))
    trainloader, testloader_dict = dm.return_dataloaders()

    # ReID-Stream:
    print("Initializing ReID-Stream: {}".format(args.arch))
    model = models.init_model(name=args.arch, num_classes=dm.num_train_pids, reid_dim=args.reid_dim, loss={'xent', 'htri'})
    print("ReID Model size: {:.3f} M".format(count_num_param(model)))

    # Gait-Stream:
    print("Initializing Gait-Stream (GCP + GaitSet) : {} and {}".format('GCP', 'GaitSet'))
    GCP = models.init_model(name='GCP', m=8) # where 8 means the number of predicted cycle
    GaitSet = models.init_model(name='GaitSet', out_channels=args.gait_dim)
    print("GCP size: {:.3f} M".format(count_num_param(GCP)))
    print("GaitSet size: {:.3f} M".format(count_num_param(GaitSet)))

    criterion_xent = CrossEntropyLoss(num_classes=dm.num_train_pids, use_gpu=use_gpu, label_smooth=args.label_smooth)
    criterion_htri = TripletLoss(margin=args.margin)
    criterion_separate_tri = FullTripletLoss(margin=0.5).cuda()
    criterion_CFL = CFLLoss().cuda()
    criterion_L1 = nn.L1Loss().cuda()

    # 2. Optimizer
    # Main ReID-Stream:
    optimizer = init_optimizer(model.parameters(), **optimizer_kwargs(args))
    scheduler = lr_scheduler.MultiStepLR(optimizer, milestones=args.stepsize, gamma=args.gamma)
    # Gait-Stream:
    params = [
        {"params_GCP": GCP.parameters(), "lr": args.lr_GCP},
        {"params_GaitSet": GaitSet.parameters(), "lr": args.lr_GaitSet},
    ]
    if args.optim == 'sgd':
        optimizer_GCP = optim.SGD(GCP.parameters(), lr=args.lr_GCP, momentum=0.9, weight_decay=5e-4)
        optimizer_GaitSet = optim.SGD(GaitSet.parameters(), lr=args.lr_GaitSet, momentum=0.9, weight_decay=5e-4)
    elif args.optim == 'adam':
        optimizer_GCP = optim.Adam(GCP.parameters(), lr=args.lr_GCP, weight_decay=1e-5)
        optimizer_GaitSet = optim.Adam(GaitSet.parameters(), lr=args.lr_GaitSet, weight_decay=1e-5)

    scheduler_GCP = lr_scheduler.MultiStepLR(optimizer_GCP, milestones=args.stepsize_GCP, gamma=args.gamma)
    scheduler_GaitSet = lr_scheduler.MultiStepLR(optimizer_GaitSet, milestones=args.stepsize_GaitSet, gamma=args.gamma)

    if args.load_weights_GCP:
        # load pretrained weights but ignore layers that don't match in size
        checkpoint = torch.load(args.load_weights_GCP)
        pretrain_dict = checkpoint['GCP_state_dict']
        model_dict = GCP.state_dict()
        pretrain_dict = {k: v for k, v in pretrain_dict.items() if k in model_dict and model_dict[k].size() == v.size()}
        model_dict.update(pretrain_dict)
        GCP.load_state_dict(model_dict)
        print("Loaded pretrained weights from '{}' for GCP".format(args.load_weights_GCP))

    if args.load_weights_GaitSet:
        # load pretrained weights but ignore layers that don't match in size
        checkpoint = torch.load(args.load_weights_GaitSet)
        pretrain_dict = checkpoint['GaitSet_state_dict']
        model_dict = GaitSet.state_dict()
        pretrain_dict = {k: v for k, v in pretrain_dict.items() if k in model_dict and model_dict[k].size() == v.size()}
        model_dict.update(pretrain_dict)
        GaitSet.load_state_dict(model_dict)
        print("Loaded pretrained weights from '{}' for GaitSet".format(args.load_weights_GaitSet))

    if use_gpu:
        model = nn.DataParallel(model).cuda()
        GCP = nn.DataParallel(GCP).cuda()
        GaitSet = nn.DataParallel(GaitSet).cuda()

    if args.evaluate:
        print("Evaluate only")

        for name in args.target_names:
            print("Evaluating {} ...".format(name))
            queryloader = testloader_dict[name]['query']
            galleryloader = testloader_dict[name]['gallery']
            distmat = test(model, queryloader, galleryloader, use_gpu, return_distmat=True)

            if args.visualize_ranks:
                visualize_ranked_results(
                    distmat, dm.return_testdataset_by_name(name),
                    save_dir=osp.join(args.save_dir, 'ranked_results', name),
                    topk=20
                )
        return

    start_time = time.time()
    ranklogger = RankLogger(args.source_names, args.target_names)
    train_time = 0
    print("==> Start training")

    for epoch in range(args.start_epoch, args.max_epoch):
        start_train_time = time.time()
        train(epoch, model, GCP, GaitSet, criterion_xent, criterion_htri, criterion_separate_tri, criterion_CFL, criterion_L1, \
              optimizer, optimizer_GCP, optimizer_GaitSet, trainloader, use_gpu)
        train_time += round(time.time() - start_train_time)

        scheduler.step()
        scheduler_GCP.step()
        scheduler_GaitSet.step()

        if (epoch + 1) > args.start_eval and args.eval_freq > 0 and (epoch + 1) % args.eval_freq == 0 or (
                epoch + 1) == args.max_epoch:
            print("==> Test")

            for name in args.target_names:
                print("Evaluating {} ...".format(name))
                queryloader = testloader_dict[name]['query']
                galleryloader = testloader_dict[name]['gallery']
                rank1 = test(model, queryloader, galleryloader, use_gpu)
                ranklogger.write(name, epoch + 1, rank1)

            if use_gpu:
                state_dict = model.module.state_dict()
                GCP_state_dict = GCP.module.state_dict()
                GaitSet_state_dict = GaitSet.module.state_dict()
            else:
                state_dict = model.state_dict()
                GCP_state_dict = GCP.state_dict()
                GaitSet_state_dict = GaitSet.state_dict()

            save_checkpoint({
                'state_dict': state_dict,
                'rank1': rank1,
                'epoch': epoch,
            }, False, osp.join(args.save_dir, 'checkpoint_ep' + str(epoch + 1) + '.pth.tar'))
            save_checkpoint({
                'GCP_state_dict': GCP_state_dict,
                'epoch': epoch,
            }, False, osp.join(args.save_dir, 'GCP_checkpoint_ep' + str(epoch + 1) + '.pth.tar'))

            save_checkpoint({
                'GaitSet_state_dict': GaitSet_state_dict,
                'epoch': epoch,
            }, False, osp.join(args.save_dir, 'GaitSet_checkpoint_ep' + str(epoch + 1) + '.pth.tar'))

    elapsed = round(time.time() - start_time)
    elapsed = str(datetime.timedelta(seconds=elapsed))
    train_time = str(datetime.timedelta(seconds=train_time))
    print("Finished. Total elapsed time (h:m:s): {}. Training time (h:m:s): {}.".format(elapsed, train_time))
    ranklogger.show_summary()


def train(epoch, model, GCP, GaitSet, criterion_xent, criterion_htri, criterion_separate_tri, criterion_CFL, criterion_L1, \
          optimizer, optimizer_GCP, optimizer_GaitSet, trainloader, use_gpu):
    losses = AverageMeter()
    batch_time = AverageMeter()
    data_time = AverageMeter()

    model.train()
    GCP.train()
    GaitSet.train()

    end = time.time()
    for batch_idx, (imgs, pids, cloth_ids, _, img_paths, masks) in enumerate(trainloader):
        data_time.update(time.time() - end)

        if use_gpu:
            imgs, pids, cloth_ids, masks = imgs.cuda(), pids.cuda(), cloth_ids.cuda(), masks.cuda()

        # gait img 64*64 only have person in the middle, but reid person 64*64 have person in the entire content, so need this pre-processing:
        padding_length = (args.mask_height - args.mask_width) // 2
        left_right_padding = nn.ZeroPad2d((padding_length, padding_length, 0, 0))
        masks = left_right_padding(masks)

        # Gait-Stream:
        gait_cycle = GCP(masks) # output features:(P*K, 8, 64, 64), input masks:(P*K, 1, 64, 44) or (P*K, 1, 256, 108)
        cut_padding = 10
        gait_outputs = GaitSet(gait_cycle[:, :, :, cut_padding:-cut_padding]) # output:[P*K, 62=2*31, 256]

        # Main ReID-Stream:
        features, outputs, features_fusion, outputs_fusion, (hs, ht), (_Fs, _Ft), (fs, ft) = model(imgs, gait_outputs)

        # ReID loss local:
        xent_loss_local = criterion_xent(outputs, pids)
        htri_loss_local = criterion_htri(features, pids)
        # ReID loss global:
        xent_loss_global = criterion_xent(outputs_fusion, pids)
        htri_loss_global = criterion_htri(features_fusion, pids)

        # CFL loss:
        mmd, mse = criterion_CFL(hs, ht, _Fs, _Ft, fs, ft)

        # GCP loss discarded and GaitSet loss:
        loss_GCP = criterion_L1(torch.mean(gait_cycle, 1, True), masks)
                   # + \
                   # criterion_L1(gait_cycle[:, gait_cycle.size()[1]//2-1, :, :], masks) # make the inner prediction consistent with mask
        loss_GaitSet = criterion_separate_tri(gait_outputs, pids)

        loss_total = args.loss_GaitSet * loss_GaitSet + args.loss_GCP * loss_GCP + \
                     args.loss_ReID_cla_local * xent_loss_local + args.loss_ReID_tri_local * htri_loss_local + \
                     args.loss_ReID_cla_global * xent_loss_global + args.loss_ReID_tri_global * htri_loss_global + \
                     args.loss_CFL * (mmd + mse)

        optimizer.zero_grad()
        optimizer_GCP.zero_grad()
        optimizer_GaitSet.zero_grad()
        loss_total.backward()
        optimizer.step()
        optimizer_GCP.step()
        optimizer_GaitSet.step()

        batch_time.update(time.time() - end)

        losses.update(loss_total.item(), pids.size(0))

        if (batch_idx + 1) % args.print_freq == 0:
            print('Epoch: [{0}][{1}/{2}]\t'
                  'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
                  'Data {data_time.val:.4f} ({data_time.avg:.4f})\t'
                  'Loss {loss.val:.4f} ({loss.avg:.4f})\t'.format(
                epoch + 1, batch_idx + 1, len(trainloader), batch_time=batch_time,
                data_time=data_time, loss=losses))

        if (epoch + 1) > args.start_eval and args.eval_freq > 0 and (epoch + 1) % args.eval_freq == 0 or (epoch + 1) == args.max_epoch:            # Save predicted gait cycle:
            # GCP.eval()
            # Save mask
            img = masks[0].squeeze().unsqueeze(0).cpu()
            img_np = np.uint8(np.floor(img.data.numpy() * 255))
            img_np = img_np.transpose((1, 2, 0))  # (c, h, w) -> (h, w, c)
            img_np[img_np > 255] = 255
            img_np = img_np.astype(np.uint8)
            path = img_paths[0]
            imname = path.split('/')[-1]
            cv2.imwrite(osp.join(args.save_vis_gait_dir, imname + 'MaskGT_No.{}_ep{}'.format(0, epoch) + '.jpg'), img_np)
            # Save gait prediction:
            # gait_cycle = GCP(masks)
            gait_cycle = gait_cycle[0].squeeze().cpu()  # features:(8, 64, 64)
            for i in range(gait_cycle.size(0)):
                path = img_paths[0]
                imname = path.split('/')[-1]  #osp.basename(osp.splitext(path)[0])
                # Grey image
                img = gait_cycle[i, :, :]
                img = img.unsqueeze(0)
                img_np = np.uint8(np.floor(img.data.numpy() * 255))
                img_np = img_np.transpose((1, 2, 0))  # (c, h, w) -> (h, w, c)
                img_np[img_np > 255] = 255
                img_np = img_np.astype(np.uint8)
                if not os.path.exists(args.save_vis_gait_dir):
                    os.makedirs(args.save_vis_gait_dir)
                cv2.imwrite(osp.join(args.save_vis_gait_dir, imname + '_No.{}_ep{}'.format(i, epoch) + '.jpg'), img_np)
        end = time.time()


def test(model, queryloader, galleryloader, use_gpu, ranks=[1, 5, 10, 20], return_distmat=False):
    batch_time = AverageMeter()

    model.eval()

    with torch.no_grad():
        qf, q_pids, q_cloth_ids, q_camids = [], [], [], []
        for batch_idx, (imgs, pids, cloth_ids, camids, _) in enumerate(queryloader):
            if use_gpu:
                imgs = imgs.cuda()

            end = time.time()
            features = model(imgs, imgs) # 其实第二个应该是gait，但是无所谓，用不到
            batch_time.update(time.time() - end)

            features = features.data.cpu()
            qf.append(features)
            q_pids.extend(pids)
            q_cloth_ids.extend(cloth_ids)
            q_camids.extend(camids)
        qf = torch.cat(qf, 0)
        q_pids = np.asarray(q_pids)
        q_cloth_ids = np.asarray(q_cloth_ids)
        q_camids = np.asarray(q_camids)

        print("Extracted features for query set, obtained {}-by-{} matrix".format(qf.size(0), qf.size(1)))

        gf, g_pids, g_cloth_ids, g_camids = [], [], [], []
        for batch_idx, (imgs, pids, cloth_ids, camids, _) in enumerate(galleryloader):
            if use_gpu:
                imgs = imgs.cuda()

            end = time.time()
            features = model(imgs, imgs)
            batch_time.update(time.time() - end)

            features = features.data.cpu()
            gf.append(features)
            g_pids.extend(pids)
            g_cloth_ids.extend(cloth_ids)
            g_camids.extend(camids)
        gf = torch.cat(gf, 0)
        g_pids = np.asarray(g_pids)
        g_cloth_ids = np.asarray(g_cloth_ids)
        g_camids = np.asarray(g_camids)

        print("Extracted features for gallery set, obtained {}-by-{} matrix".format(gf.size(0), gf.size(1)))

    print("==> BatchTime(s)/BatchSize(img): {:.3f}/{}".format(batch_time.avg, args.test_batch_size))

    m, n = qf.size(0), gf.size(0)
    distmat = torch.pow(qf, 2).sum(dim=1, keepdim=True).expand(m, n) + \
              torch.pow(gf, 2).sum(dim=1, keepdim=True).expand(n, m).t()
    distmat.addmm_(1, -2, qf, gf.t())
    distmat = distmat.numpy()

    print("Computing CMC and mAP")
    cmc, mAP = evaluate(distmat, q_pids, g_pids, q_cloth_ids, g_cloth_ids, q_camids, g_camids, use_metric_cuhk03=args.use_metric_cuhk03)

    print("Results ----------")
    print("mAP: {:.1%}".format(mAP))
    print("CMC curve")
    for r in ranks:
        print("Rank-{:<3}: {:.1%}".format(r, cmc[r - 1]))
    print("------------------")

    if return_distmat:
        return distmat
    return cmc[0]


if __name__ == '__main__':
    main()
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
'''
Author             : jin xin (kevin.jx@alibaba-inc.com)
Date               : 2022-05-23 11:14
Last Modified By   : jin xin (kevin.jx@alibaba-inc.com)
Last Modified Date : 2022-06-18 18:42
Description        : CVPR-2022
-------- 
Copyright (c) 2022 Alibaba Inc. 
'''

from __future__ import print_function
from __future__ import division

import os
import sys
import time
import datetime
import os.path as osp
import numpy as np
import cv2

import torch
import torch.nn as nn
import torch.backends.cudnn as cudnn
from torch.utils.data import DataLoader
from torch.optim import lr_scheduler
import torch.optim as optim

from args import argument_parser, video_dataset_kwargs, optimizer_kwargs
from torchreid.data_manager import VideoDataManager
from torchreid import models
from torchreid.losses import CrossEntropyLoss, TripletLoss, DeepSupervision, FullTripletLoss
from torchreid.utils.iotools import save_checkpoint, check_isfile
from torchreid.utils.avgmeter import AverageMeter
from torchreid.utils.loggers import Logger, RankLogger
from torchreid.utils.torchtools import count_num_param, open_all_layers, open_specified_layers
from torchreid.utils.reidtools import visualize_ranked_results
from torchreid.eval_metrics import evaluate
from torchreid.samplers import RandomIdentitySampler
from torchreid.optimizers import init_optimizer


# global variables
parser = argument_parser()
args = parser.parse_args()


def main():
    global args
    
    torch.manual_seed(args.seed)
    if not args.use_avai_gpus: os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu_devices
    use_gpu = torch.cuda.is_available()
    if args.use_cpu: use_gpu = False
    log_name = 'log_test.txt' if args.evaluate else 'log_train.txt'
    sys.stdout = Logger(osp.join(args.save_dir, log_name))
    print("==========\nArgs:{}\n==========".format(args))

    if use_gpu:
        print("Currently using GPU {}".format(args.gpu_devices))
        cudnn.benchmark = True
        torch.cuda.manual_seed_all(args.seed)
    else:
        print("Currently using CPU, however, GPU is highly recommended")

    print("Initializing video data manager")
    dm = VideoDataManager(use_gpu, **video_dataset_kwargs(args))
    trainloader, testloader_dict = dm.return_dataloaders()

    print("Initializing model: {} and {}".format('GCP', 'GaitSet'))
    GCP = models.init_model(name='GCP', m=8)
    GaitSet = models.init_model(name='GaitSet', out_channels=256)
    print("GCP size: {:.3f} M".format(count_num_param(GCP)))
    print("GaitSet size: {:.3f} M".format(count_num_param(GaitSet)))

    criterion_ID = nn.CrossEntropyLoss().cuda()
    criterion_separate_tri = FullTripletLoss(margin=0.5).cuda()

    # 2. Optimizer
    params = [
        {"params_GCP": GCP.parameters(), "lr": args.lr_GCP},
        {"params_GaitSet": GaitSet.parameters(), "lr": args.lr_GaitSet},
    ]
    if args.optim == 'sgd':
        optimizer_GCP = optim.SGD(GCP.parameters(), lr=args.lr_GCP, momentum=0.9, weight_decay=1e-4)
        optimizer_GaitSet = optim.SGD(GaitSet.parameters(), lr=args.lr_GaitSet, momentum=0.9, weight_decay=1e-4)
    elif args.optim == 'adam':
        optimizer_GCP = optim.Adam(GCP.parameters(), lr=args.lr_GCP, weight_decay=1e-5)
        optimizer_GaitSet = optim.Adam(GaitSet.parameters(), lr=args.lr_GaitSet, weight_decay=1e-5)

    scheduler_GCP = lr_scheduler.MultiStepLR(optimizer_GCP, milestones=args.stepsize_GCP, gamma=args.gamma)
    scheduler_GaitSet = lr_scheduler.MultiStepLR(optimizer_GaitSet, milestones=args.stepsize_GaitSet, gamma=args.gamma)

    if args.load_weights and check_isfile(args.load_weights):
        # load pretrained GaitSet weights but ignore layers that don't match in size
        checkpoint = torch.load(args.load_weights)
        pretrain_dict = checkpoint
        model_dict = GaitSet.state_dict()
        pretrain_dict = {k: v for k, v in pretrain_dict.items() if k in model_dict and model_dict[k].size() == v.size()}
        model_dict.update(pretrain_dict)
        GaitSet.load_state_dict(model_dict)
        print("Loaded pretrained weights from '{}'".format(args.load_weights))

    if use_gpu:
        GCP = nn.DataParallel(GCP).cuda()
        GaitSet = nn.DataParallel(GaitSet).cuda()

    # if args.evaluate:
    #     print("Evaluate only")
    #
    #     for name in args.target_names:
    #         print("Evaluating {} ...".format(name))
    #         queryloader = testloader_dict[name]['query']
    #         galleryloader = testloader_dict[name]['gallery']
    #         distmat = test(model, queryloader, galleryloader, args.pool_tracklet_features, use_gpu, return_distmat=True)
    #
    #         if args.visualize_ranks:
    #             visualize_ranked_results(
    #                 distmat, dm.return_testdataset_by_name(name),
    #                 save_dir=osp.join(args.save_dir, 'ranked_results', name),
    #                 topk=20
    #             )
    #     return

    start_time = time.time()
    ranklogger = RankLogger(args.source_names, args.target_names)
    train_time = 0
    print("==> Start training")

    for epoch in range(args.start_epoch, args.max_epoch):
        start_train_time = time.time()
        if epoch < args.epochs_only_for_GCP:
            train_GCP(epoch, GCP, GaitSet, optimizer_GCP, optimizer_GaitSet, trainloader, use_gpu)
        else:
            train_GCP_GaitSet(epoch, GCP, GaitSet, criterion_ID, criterion_separate_tri, optimizer_GCP, optimizer_GaitSet, trainloader, use_gpu)
        train_time += round(time.time() - start_train_time)
        
        scheduler_GCP.step()
        scheduler_GaitSet.step()
        
        if (epoch + 1) > args.start_eval and args.eval_freq > 0 and (epoch + 1) % args.eval_freq == 0 or (epoch + 1) == args.max_epoch:

            # print("==> Test")
            # for name in args.target_names:
            #     print("Evaluating {} ...".format(name))
            #     queryloader = testloader_dict[name]['query']
            #     galleryloader = testloader_dict[name]['gallery']
            #     rank1 = test(model, queryloader, galleryloader, args.pool_tracklet_features, use_gpu)
            #     ranklogger.write(name, epoch + 1, rank1)

            if use_gpu:
                GCP_state_dict = GCP.module.state_dict()
                GaitSet_state_dict = GaitSet.module.state_dict()
            else:
                GCP_state_dict = GCP.state_dict()
                GaitSet_state_dict = GaitSet.state_dict()
            
            save_checkpoint({
                'GCP_state_dict': GCP_state_dict,
                'epoch': epoch,
            }, False, osp.join(args.save_dir, 'GCP_checkpoint_ep' + str(epoch + 1) + '.pth.tar'))

            save_checkpoint({
                'GaitSet_state_dict': GaitSet_state_dict,
                'epoch': epoch,
            }, False, osp.join(args.save_dir, 'GaitSet_checkpoint_ep' + str(epoch + 1) + '.pth.tar'))

    elapsed = round(time.time() - start_time)
    elapsed = str(datetime.timedelta(seconds=elapsed))
    train_time = str(datetime.timedelta(seconds=train_time))
    print("Finished. Total elapsed time (h:m:s): {}. Training time (h:m:s): {}.".format(elapsed, train_time))
    ranklogger.show_summary()

def train_GCP(epoch, GCP, GaitSet, optimizer_GCP, optimizer_GaitSet, trainloader, use_gpu):
    losses = AverageMeter()
    batch_time = AverageMeter()
    data_time = AverageMeter()

    GCP.train()
    GaitSet.eval()

    end = time.time()
    for batch_idx, (imgs, pids, _, imgs_path) in enumerate(trainloader):
        data_time.update(time.time() - end)

        if use_gpu:
            imgs, pids = imgs.cuda(), pids.cuda()

        # selected_middle_image_index = []
        # for i in range(args.train_batch_size // args.seq_len):
        #     selected_middle_image_index.append(args.middle_idx + i * args.seq_len)
        # selected_middle_image_index = torch.tensor(selected_middle_image_index).cuda()

        features = GCP(imgs[:, args.middle_idx, :, :, :].squeeze().unsqueeze(1)) # output features:(8*4, 8, 64, 64), selected input imgs:(8*4, 1, 64, 44), pratical input imgs:(8*4, 8, 1, 64, 44)

        mse = nn.L1Loss()
        loss = mse(features, imgs.squeeze())
        optimizer_GCP.zero_grad()
        optimizer_GaitSet.zero_grad()
        loss.backward()
        optimizer_GCP.step()
        optimizer_GaitSet.step()

        batch_time.update(time.time() - end)

        losses.update(loss.item(), pids.size(0))

        if (batch_idx + 1) % args.print_freq == 0:
            print('Epoch: [{0}][{1}/{2}]\t'
                  'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
                  'Data {data_time.val:.4f} ({data_time.avg:.4f})\t'
                  'Loss_mse {loss.val:.4f} ({loss.avg:.4f})\t'.format(
                epoch + 1, batch_idx + 1, len(trainloader), batch_time=batch_time,
                data_time=data_time, loss=losses))

        if (epoch + 1) > args.start_eval and args.eval_freq > 0 and (epoch + 1) % args.eval_freq == 0 or (epoch + 1) == args.max_epoch:
            # Save predicted gait cycle:
            features = features[0].squeeze().cpu() # features:(8, 64, 64)
            for i in range(features.size(0)):
                path = imgs_path[i][0]
                imname = path.split('/')[-1]  #osp.basename(osp.splitext(path)[0])
                # Grey image
                img = features[i, :, :]
                img = img.unsqueeze(0)
                img_np = np.uint8(np.floor(img.data.numpy() * 255))
                img_np = img_np.transpose((1, 2, 0))  # (c, h, w) -> (h, w, c)
                img_np[img_np > 255] = 255
                img_np = img_np.astype(np.uint8)
                if not os.path.exists(args.save_vis_gait_dir):
                    os.makedirs(args.save_vis_gait_dir)
                cv2.imwrite(osp.join(args.save_vis_gait_dir, imname + '_ep{}'.format(epoch) + '.jpg'), img_np)

        end = time.time()


def train_GCP_GaitSet(epoch, GCP, GaitSet, criterion_ID, criterion_separate_tri, optimizer_GCP, optimizer_GaitSet, trainloader, use_gpu):
    losses = AverageMeter()
    batch_time = AverageMeter()
    data_time = AverageMeter()

    GCP.train()
    GaitSet.train()

    end = time.time()
    for batch_idx, (imgs, pids, _, imgs_path) in enumerate(trainloader):
        data_time.update(time.time() - end)
        
        if use_gpu:
            imgs, pids = imgs.cuda(), pids.cuda()

        # selected_middle_image_index = []
        # for i in range(args.train_batch_size // args.seq_len):
        #     selected_middle_image_index.append(args.middle_idx + i * args.seq_len)
        # selected_middle_image_index = torch.tensor(selected_middle_image_index).cuda()

        features = GCP(imgs[:, args.middle_idx, :, :, :].squeeze().unsqueeze(1)) # output features:(8*4, 8, 64, 64), selected input imgs:(8*4, 1, 64, 44), pratical input imgs:(8*4, 8, 1, 64, 44)
        cut_padding = 10
        outputs = GaitSet(features[:, :, :, cut_padding:-cut_padding])
        # print(outputs.size()) # [8*4, 62=2*31, 256]

        mse = nn.L1Loss()
        loss_GCP = mse(features, imgs.squeeze())
        loss_GaitSet = criterion_separate_tri(outputs, pids)
        loss_total = args.loss_GaitSet * loss_GaitSet + args.loss_GCP * loss_GCP
        optimizer_GCP.zero_grad()
        optimizer_GaitSet.zero_grad()
        loss_total.backward()
        optimizer_GCP.step()
        optimizer_GaitSet.step()

        batch_time.update(time.time() - end)

        losses.update(loss_total.item(), pids.size(0))

        if (batch_idx + 1) % args.print_freq == 0:
            print('Epoch: [{0}][{1}/{2}]\t'
                  'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
                  'Data {data_time.val:.4f} ({data_time.avg:.4f})\t'
                  'Loss {loss.val:.4f} ({loss.avg:.4f})\t'.format(
                   epoch + 1, batch_idx + 1, len(trainloader), batch_time=batch_time,
                   data_time=data_time, loss=losses))

        if (epoch + 1) > args.start_eval and args.eval_freq > 0 and (epoch + 1) % args.eval_freq == 0 or (epoch + 1) == args.max_epoch:            # Save predicted gait cycle:
            features = features[0].squeeze().cpu() # features:(8, 64, 64)
            for i in range(features.size(0)):
                path = imgs_path[i][0]
                imname = path.split('/')[-1]  #osp.basename(osp.splitext(path)[0])
                # Grey image
                img = features[i, :, :]
                img = img.unsqueeze(0)
                img_np = np.uint8(np.floor(img.data.numpy() * 255))
                img_np = img_np.transpose((1, 2, 0))  # (c, h, w) -> (h, w, c)
                img_np[img_np > 255] = 255
                img_np = img_np.astype(np.uint8)
                if not os.path.exists(args.save_vis_gait_dir):
                    os.makedirs(args.save_vis_gait_dir)
                cv2.imwrite(osp.join(args.save_vis_gait_dir, imname + '_ep{}'.format(epoch) + '.jpg'), img_np)
        end = time.time()


# def test(model, queryloader, galleryloader, pool, use_gpu, ranks=[1, 5, 10, 20], return_distmat=False):
#     batch_time = AverageMeter()
#
#     model.eval()
#
#     with torch.no_grad():
#         qf, q_pids, q_camids = [], [], []
#         for batch_idx, (imgs, pids, camids) in enumerate(queryloader):
#             if use_gpu: imgs = imgs.cuda()
#             b, s, c, h, w = imgs.size()
#             imgs = imgs.view(b*s, c, h, w)
#
#             end = time.time()
#             features = model(imgs)
#             batch_time.update(time.time() - end)
#
#             features = features.view(b, s, -1)
#             if pool == 'avg':
#                 features = torch.mean(features, 1)
#             else:
#                 features, _ = torch.max(features, 1)
#             features = features.data.cpu()
#             qf.append(features)
#             q_pids.extend(pids)
#             q_camids.extend(camids)
#         qf = torch.cat(qf, 0)
#         q_pids = np.asarray(q_pids)
#         q_camids = np.asarray(q_camids)
#
#         print("Extracted features for query set, obtained {}-by-{} matrix".format(qf.size(0), qf.size(1)))
#
#         gf, g_pids, g_camids = [], [], []
#         for batch_idx, (imgs, pids, camids) in enumerate(galleryloader):
#             if use_gpu: imgs = imgs.cuda()
#             b, s, c, h, w = imgs.size()
#             imgs = imgs.view(b*s, c, h, w)
#
#             end = time.time()
#             features = model(imgs)
#             batch_time.update(time.time() - end)
#
#             features = features.view(b, s, -1)
#             if pool == 'avg':
#                 features = torch.mean(features, 1)
#             else:
#                 features, _ = torch.max(features, 1)
#             features = features.data.cpu()
#             gf.append(features)
#             g_pids.extend(pids)
#             g_camids.extend(camids)
#         gf = torch.cat(gf, 0)
#         g_pids = np.asarray(g_pids)
#         g_camids = np.asarray(g_camids)
#
#         print("Extracted features for gallery set, obtained {}-by-{} matrix".format(gf.size(0), gf.size(1)))
#
#     print("==> BatchTime(s)/BatchSize(img): {:.3f}/{}".format(batch_time.avg, args.test_batch_size * args.seq_len))
#
#     m, n = qf.size(0), gf.size(0)
#     distmat = torch.pow(qf, 2).sum(dim=1, keepdim=True).expand(m, n) + \
#               torch.pow(gf, 2).sum(dim=1, keepdim=True).expand(n, m).t()
#     distmat.addmm_(1, -2, qf, gf.t())
#     distmat = distmat.numpy()
#
#     print("Computing CMC and mAP")
#     cmc, mAP = evaluate(distmat, q_pids, g_pids, q_camids, g_camids)
#
#     print("Results ----------")
#     print("mAP: {:.1%}".format(mAP))
#     print("CMC curve")
#     for r in ranks:
#         print("Rank-{:<3}: {:.1%}".format(r, cmc[r-1]))
#     print("------------------")
#
#     if return_distmat:
#         return distmat
#     return cmc[0]


if __name__ == '__main__':
    main()

# GI-ReID
Code release for CVPR-2022 paper titled "Cloth-Changing Person Re-identification from A Single Image with Gait Prediction and Regularization".


# Training and eval setting of Baseline w.r.t the different cloth-changing datasets

## LTCC standard eval setting (all training setting):
nohup python train_Baseline.py --gpu-devices 1 --root /DATASET_PATH/Cloth-ReID/reid_datasets/ -s ltcc -t ltcc -a resnet50_fc512 --height 256 --width 128 --max-epoch 60 --stepsize 20 40 --lr 0.0003 --train-batch-size 32 --test-batch-size 100 --save-dir SAVE_PATH --train-with-all-cloth --use-standard-metric --eval-freq 10 > ./debug3.log 2>&1 &

## LTCC cloth-changing eval setting (all training setting):
### Note that, if use --use-cloth-changing-metric, must add (g_pids[order] == q_pid) & ((g_cloids[order] == q_cloid) | (g_camids[order] == q_camid)):
nohup python train_Baseline.py --gpu-devices 1 --root /DATASET_PATH/Cloth-ReID/reid_datasets/ -s ltcc -t ltcc -a resnet50_fc512 --height 256 --width 128 --max-epoch 60 --stepsize 20 40 --lr 0.0003 --train-batch-size 32 --test-batch-size 100 --save-dir SAVE_PATH --train-with-all-cloth --use-cloth-changing-metric --eval-freq 10 > ./debug5.log 2>&1 &

## PRCC same-cloth eval setting:
### must using cuhk03 eval protocal, and did not remove anything:
nohup python train_Baseline.py --gpu-devices 1 --root /DATASET_PATH/Cloth-ReID/reid_datasets/ -s prcc -t prcc -a resnet50_fc512 --height 256 --width 128 --max-epoch 60 --stepsize 20 40 --lr 0.0003 --train-batch-size 32 --test-batch-size 100 --save-dir SAVE_PATH --same-clothes  --just-for-prcc-test --use-metric-cuhk03 --eval-freq 10 > ./debug8_prcc.log 2>&1 &

## PRCC cloth-changing eval setting:
nohup python train_Baseline.py --gpu-devices 1 --root /DATASET_PATH/Cloth-ReID/reid_datasets/ -s prcc -t prcc -a resnet50_fc512 --height 256 --width 128 --max-epoch 60 --stepsize 20 40 --lr 0.0003 --train-batch-size 32 --test-batch-size 100 --save-dir SAVE_PATH --cross-clothes  --just-for-prcc-test --use-metric-cuhk03 --eval-freq 10 > ./debug9_prcc.log 2>&1 &

# Training of the proposed method:

## Gait Sequence Prediction (GSP) + GaitSet training:
nohup python train_Gait_Stream.py --gpu-devices 0 --root /DATASET_PATH/Gait_related/ -s casiab_processed -t casiab_processed --height 256 --width 128 --max-epoch 10000 --train-batch-size 32 --save-dir SAVE_PATH --train-sampler RandomIdentitySampler --eval-freq 1000 --epochs-only-for-GCP 2000 --stepsize_GCP 1000 4000 8000 --stepsize_GaitSet 4000 8000 > ./out.log 2>&1 &

## Entire framework training:
nohup python train_GaitReID.py --gpu-devices 0 --root /DATASET_PATH/Cloth-ReID/reid_datasets/ -s ltcc -t ltcc -a GaitReID --height 256 --width 128 --mask-height 64 --mask-width 32 --max-epoch 160 --stepsize 40 80 120 --lr 8e-4 --stepsize_GCP 160 --stepsize_GaitSet 160 --lr_GCP 1e-4 --lr_GaitSet 1e-4 --train-batch-size 24 --test-batch-size 100 --save-dir SAVE_PATH --train-sampler RandomIdentitySampler --eval-freq 40 --load-weights-GCP /SAVE_PATH/GCP_checkpoint_ep10000.pth.tar --load-weights-GaitSet /SAVE_PATH/GaitSet_checkpoint_ep10000.pth.tar --train-with-all-cloth --use-standard-metric > ./out.log 2>&1 &


nohup python train_GaitReID.py --gpu-devices 0 --root /data1/Datasets_jinx/Cloth-ReID/reid_datasets/ \
-s ltcc -t ltcc -a GaitReID --height 256 --width 128 --mask-height 64 --mask-width 32 \
--max-epoch 120 --stepsize 80 160 --lr 5e-4 --stepsize_GCP 320 --stepsize_GaitSet 320 --lr_GCP 1e-5 --lr_GaitSet 1e-5 --train-batch-size 80 --test-batch-size 10 \
--loss-GaitSet 0.01 --loss-GCP 0.1 \
--reid-dim 2048 --gait-dim 2048 \
--save-dir /data1/Projects_jinx/GaitReID_log_vis/log/1105_LTCC_train_with_all_imgs_Standard_with_GCPweight_h64w64_loss_balance_BS48_dim2048_h256w128_lr5e04_BS80_withoutRE \
--save-vis-gait-dir /data1/Projects_jinx/GaitReID_log_vis/Vis_predicted_gait_cycle/Vis_GaitReID/1105_LTCC_train_with_all_imgs_Standard_with_GCPweight_h64w64_loss_balance_BS48_dim2048_h256w128_lr5e04_BS80_withoutRE/ \
--train-sampler RandomIdentitySampler --eval-freq 40 \
--load-weights-GCP /data1/Projects_jinx/GaitReID_log_vis/log/1031_casiab_processed_1wepochs_h64w64/GCP_checkpoint_ep10000.pth.tar \
--load-weights-GaitSet /data1/Projects_jinx/GaitReID_log_vis/log/1031_casiab_processed_1wepochs_h64w64/GaitSet_checkpoint_ep10000.pth.tar \
--train-with-all-cloth --use-standard-metric > ./out.log 2>&1 &



nohup python train_GaitReID.py --gpu-devices 1 --root /data1/Datasets_jinx/Cloth-ReID/reid_datasets/ \
-s ltcc -t ltcc -a GaitReID --height 256 --width 128 --mask-height 64 --mask-width 32 \
--max-epoch 120 --stepsize 80 160 --lr 5e-4 --stepsize_GCP 320 --stepsize_GaitSet 320 --lr_GCP 1e-5 --lr_GaitSet 1e-5 --train-batch-size 80 --test-batch-size 10 \
--loss-GaitSet 0.01 --loss-GCP 0.1 \
--reid-dim 2048 --gait-dim 2048 \
--save-dir /data1/Projects_jinx/GaitReID_log_vis/log/1108_LTCC_train_with_all_imgs_Standard_with_GCPweight_h64w64_loss_balance_BS48_dim2048_h256w128_lr5e04_BS80_withoutRE_Cloth_Meric \
--save-vis-gait-dir /data1/Projects_jinx/GaitReID_log_vis/Vis_predicted_gait_cycle/Vis_GaitReID/1108_LTCC_train_with_all_imgs_Standard_with_GCPweight_h64w64_loss_balance_BS48_dim2048_h256w128_lr5e04_BS80_withoutRE_Cloth_Meric/ \
--train-sampler RandomIdentitySampler --eval-freq 40 \
--load-weights-GCP /data1/Projects_jinx/GaitReID_log_vis/log/1031_casiab_processed_1wepochs_h64w64/GCP_checkpoint_ep10000.pth.tar \
--load-weights-GaitSet /data1/Projects_jinx/GaitReID_log_vis/log/1031_casiab_processed_1wepochs_h64w64/GaitSet_checkpoint_ep10000.pth.tar \
--train-with-all-cloth --use-cloth-changing-metric > ./out.log 2>&1 &

import torch
import torch.nn as nn
import torch.nn.functional as F


class PAGCR(nn.Module):
    '''
    Encoder:
    Input: 1 * 64 * 64
    Output: 100D features
    Nets: 4* {conv2D (filter size 4*4, stride 2, # of filters [64, 128, 256, 512]) + BN + ReLU} + FC

    Phase_Estimator:
    Input: 1 * 64 * 64
    Output: 2D Label
    Nets: 4* {conv2D (filter size 4*4, stride 2, # of filters [64, 128, 256, 512]) + BN + ReLU} + FC + (FC + N)

    Feature_Transformer:
    Input: 102D features (100D feature + 2D phase estimator)
    Output: 100D features
    Nets: FC

    Decoder:
    Input: 100D transformed features
    Output: M * 64 * 64 (M is pre-defined)
    Nets: FC + 4* {deconv2D (filter size 4*4, stride 2, # of filters [64, 128, 256, 512]) + BN + ReLU} + sigmoid
    '''

    def __init__(self, m=8):
        super(PAGCR, self).__init__()
        self.m = m
        self.encoder = nn.Sequential(
            nn.Conv2d(1, 64, 3, stride=2, padding=1),  # (N, 1, 64, 64) -> (N,  64, 32, 32)
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.Conv2d(64, 128, 3, stride=2, padding=1),  # (N, 64, 32, 32) -> (N,  128, 16, 16)
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.Conv2d(128, 256, 3, stride=2, padding=1),  # (N,  128, 16, 16) -> (N,  256, 8, 8)
            nn.BatchNorm2d(256),
            nn.ReLU(),
            nn.Conv2d(256, 512, 3, stride=2, padding=1),  # (N,  256, 8, 8) -> (N,  512, 4, 4)
            nn.BatchNorm2d(512),
            nn.ReLU()
            # # an affine operation: y = Wx + b
            # nn.Linear(512 * 6 * 3, 100)  # 3*3 from image dimension
        )

        # self.phaseEst = nn.Sequential(
        #     nn.Conv2d(1, 64, 4, stride=2), # (N, 1, 64, 64) -> (N,  64, 31, 31)
        #     nn.BatchNorm2d(64),
        #     nn.ReLU(),
        #     nn.Conv2d(64, 128, 4, stride=2), # (N, 64, 31, 31) -> (N,  128, 14, 14)
        #     nn.BatchNorm2d(128),
        #     nn.ReLU(),
        #     nn.Conv2d(128, 256, 4, stride=2), # (N,  128, 14, 14) -> (N,  256, 6, 6)
        #     nn.BatchNorm2d(256),
        #     nn.ReLU(),
        #     nn.Conv2d(256, 512, 4, stride=2), # (N,  256, 6, 6) -> (N,  512, 3, 3)
        #     nn.BatchNorm2d(512),
        #     nn.ReLU(),
        #     # an affine operation: y = Wx + b
        #     nn.Linear(512 * 3 * 3, 100),  # 3*3 from image dimension
        #     nn.Linear(100, 2), # regress 2D label
        #     nn.BatchNorm1d(2) # normalize the label
        # )
        #
        # self.ftrans = nn.Sequential(
        #     nn.Linear(102, 100)
        # )

        self.decoder = nn.Sequential(
            # nn.Linear(100, 512 * 6 * 3), # reshaping the features
            nn.ConvTranspose2d(512, 256, 3, stride=2, padding=1, output_padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(),
            nn.ConvTranspose2d(256, 128, 3, stride=2, padding=1, output_padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.ConvTranspose2d(128, 64, 3, stride=2, padding=1, output_padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.ConvTranspose2d(64, self.m, 3, stride=2, padding=1, output_padding=1),
            nn.Sigmoid()  #
        )

    def forward(self, x):
        f = self.encoder(x)
        # p_hat = self.phase_estimation(x)
        # f_trans = self.ftrans(f.cat(p_hat))
        # for i in range(4):
        #     x = self.decoder[i](f)
        #     print(x.size())
        # f_dec = x
        f_dec = self.decoder(f)
        return f_dec

if __name__ == '__main__':
    model = PAGCR()
    input = torch.ones(32,1,64,64)
    output = model(input)
    print(output.shape) # Need also 64*64


# import torch
# import torch.nn as nn
# import torch.nn.functional as F
#
#
# class PAGCR(nn.Module):
#     '''
#     Encoder:
#     Input: 1 * 64 * 64
#     Output: 100D features
#     Nets: 4* {conv2D (filter size 4*4, stride 2, # of filters [64, 128, 256, 512]) + BN + ReLU} + FC
#
#     Phase_Estimator:
#     Input: 1 * 64 * 64
#     Output: 2D Label
#     Nets: 4* {conv2D (filter size 4*4, stride 2, # of filters [64, 128, 256, 512]) + BN + ReLU} + FC + (FC + N)
#
#     Feature_Transformer:
#     Input: 102D features (100D feature + 2D phase estimator)
#     Output: 100D features
#     Nets: FC
#
#     Decoder:
#     Input: 100D transformed features
#     Output: M * 64 * 64 (M is pre-defined)
#     Nets: FC + 4* {deconv2D (filter size 4*4, stride 2, # of filters [64, 128, 256, 512]) + BN + ReLU} + sigmoid
#     '''
#     def __init__(self, m=8):
#         super(PAGCR, self).__init__()
#         self.m = m
#         self.encoder = nn.Sequential(
#             nn.Conv2d(1, 64, 4, stride=2, padding=1), # (N, 1, 64, 64) -> (N,  64, 32, 32)
#             nn.BatchNorm2d(64),
#             nn.ReLU(),
#             nn.Conv2d(64, 128, 4, stride=2, padding=1), # (N, 64, 32, 32) -> (N,  128, 16, 16)
#             nn.BatchNorm2d(128),
#             nn.ReLU(),
#             nn.Conv2d(128, 256, 4, stride=2, padding=1), # (N,  128, 16, 16) -> (N,  256, 8, 8)
#             nn.BatchNorm2d(256),
#             nn.ReLU(),
#             nn.Conv2d(256, 512, 4, stride=2, padding=1), # (N,  256, 8, 8) -> (N,  512, 4, 4)
#             nn.BatchNorm2d(512),
#             nn.ReLU()
#             # # an affine operation: y = Wx + b
#             # nn.Linear(512 * 6 * 3, 100)  # 3*3 from image dimension
#         )
#
#         # self.phaseEst = nn.Sequential(
#         #     nn.Conv2d(1, 64, 4, stride=2), # (N, 1, 64, 64) -> (N,  64, 31, 31)
#         #     nn.BatchNorm2d(64),
#         #     nn.ReLU(),
#         #     nn.Conv2d(64, 128, 4, stride=2), # (N, 64, 31, 31) -> (N,  128, 14, 14)
#         #     nn.BatchNorm2d(128),
#         #     nn.ReLU(),
#         #     nn.Conv2d(128, 256, 4, stride=2), # (N,  128, 14, 14) -> (N,  256, 6, 6)
#         #     nn.BatchNorm2d(256),
#         #     nn.ReLU(),
#         #     nn.Conv2d(256, 512, 4, stride=2), # (N,  256, 6, 6) -> (N,  512, 3, 3)
#         #     nn.BatchNorm2d(512),
#         #     nn.ReLU(),
#         #     # an affine operation: y = Wx + b
#         #     nn.Linear(512 * 3 * 3, 100),  # 3*3 from image dimension
#         #     nn.Linear(100, 2), # regress 2D label
#         #     nn.BatchNorm1d(2) # normalize the label
#         # )
#         #
#         # self.ftrans = nn.Sequential(
#         #     nn.Linear(102, 100)
#         # )
#
#         self.decoder = nn.Sequential(
#             # nn.Linear(100, 512 * 6 * 3), # reshaping the features
#             nn.ConvTranspose2d(512, 256, 4, stride=2, padding=1),
#             nn.ConvTranspose2d(256, 128, 4, stride=2, padding=1),
#             nn.ConvTranspose2d(128, 64, 4, stride=2, padding=1),
#             nn.ConvTranspose2d(64, self.m, 4, stride=2, padding=1),
#             nn.Sigmoid() #
#         )
#
#     def forward(self,x):
#         f = self.encoder(x)
#         # p_hat = self.phase_estimation(x)
#         # f_trans = self.ftrans(f.cat(p_hat))
#         f_dec = self.decoder(f)
#         return f_dec
#
# if __name__ == '__main__':
#     model = PAGCR()
#     input = torch.ones(32,1,64,64)
#     output = model(input)
#     print(output.shape) # Need also 64*64

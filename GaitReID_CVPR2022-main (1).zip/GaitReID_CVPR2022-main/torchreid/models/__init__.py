from __future__ import absolute_import

from .resnet import *

from .gaitset_v2 import *
from .PCG import *

from .GaitReID import *
from .GaitReID_baseline import *
from .GaitReID_OSNet import *

__model_factory = {
    # image classification models
    'resnet50': resnet50,
    'resnet50_fc512': resnet50_fc512,
    # gait recognition models
    'GaitSet': SetNetO,
    'GCP': PAGCR,
    'GaitReID': resnet50_fc256_with_CFL,
    'GaitReID_baseline': resnet50_fc256,
    'GaitReID_baseline_with_mask': resnet50_fc256_with_mask,
    'GaitReID_OSNet': osnet_x1_0_with_CFL,
    'GaitReID_baseline_OSNet': osnet_x1_0,
}


def get_names():
    return list(__model_factory.keys())


def init_model(name, *args, **kwargs):
    if name not in list(__model_factory.keys()):
        raise KeyError("Unknown model: {}".format(name))
    return __model_factory[name](*args, **kwargs)
## How to prepare data

Create a directory to store reid datasets under this repo via
```bash
cd GaitReID_CVPR2021-main/
mkdir data/
```

If you wanna store datasets in another directory, you need to specify `--root path_to_your/data` when running the training code. Please follow the instructions below to prepare each dataset. After that, you can simply do `-d the_dataset` when running the training code. 


### ReID Datasets

**PRCC**:
1. Qize Yang, Ancong Wu, and Wei-Shi Zheng. Person reidentification by contour sketch under moderate clothing
change. TPAMI, 2019.
2. This dataset is available at: http://www.isee-ai.cn/%7Eyangqize/clothing.html

**LTCC**:
1. Xuelin Qian, Wenxuan Wang, Li Zhang, Fangrui Zhu, Yanwei Fu, Tao Xiang, Yu-Gang Jiang, and Xiangyang Xue.
Long-term cloth-changing person re-identification. WACV,
2020.
2. This dataset is available at: https://naiq.github.io/LTCC_Perosn_ReID.html

**Real28, VC-Clothes**:
1. Fangbin Wan, Yang Wu, Xuelin Qian, Yixiong Chen, and Yanwei Fu. When person re-identification meets changing clothes. In CVPRW, pages 830–831, 2020.
2. This dataset is available at: https://wanfb.github.io/dataset.html.


**CASIA Gait Database**:
1. Gait recognition has been an active research topic in recent years. The Institute of Automation, Chinese Academy of Sciences (CASIA) provide the CASIA Gait Database to gait recognition and related researchers in order to promote the research. In the CASIA Gait Database there are three datasets: Dataset A, Dataset B (multiview dataset) and Dataset C (infrared dataset)..
2. This dataset is available at: http://www.cbsr.ia.ac.cn/english/Gait%20Databases.asp.